import tkinter as tk

from Windows.DisplayAllLecturers import DisplayAllLecturersWindow
from Windows.DisplayAllStudents import DisplayAllStudentsWindow

#display all students
def ReadAllStudents():
    DisplayAllStudentsWindow()
#display all lecturers
def ReadAllLecturers():
     DisplayAllLecturersWindow()