bg_colour_darker = "#002855"
bg_colour = "#335C81"
fg_colour = "White"
window_size = '800x600'
window_title = "SSX361 Project Milestone 2"
main_window_Heading = "Student Management System"
fontM = "TkMenuFont"
fontsizeBig = 18
fontsizeSmall = 14

